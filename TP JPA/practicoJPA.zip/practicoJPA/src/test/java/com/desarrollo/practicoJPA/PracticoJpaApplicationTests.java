package com.desarrollo.practicoJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
