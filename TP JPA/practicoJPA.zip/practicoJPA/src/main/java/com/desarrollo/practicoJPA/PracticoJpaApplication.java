package com.desarrollo.practicoJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticoJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticoJpaApplication.class, args);
	}

}
